require("./loja");

require("./usuario");
require("./cliente");

require("./categoria");
require("./produto");
require("./avaliacao");
require("./variacao");

require("./pedido");
require("./pagamento");
require("./entrega");

require("./registroPedido");