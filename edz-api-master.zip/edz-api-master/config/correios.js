module.exports = {
    // nCdEmpresa: "",
    // sDsSenha :"",
    nCdServico: "40010,41106", // Sedex Varejo e PAC Varejo,
    sCepOrigem: "04852-410"
};